export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  const { id, server } = req.body;
  if (!id || !server) {
    return res.status(400).json({ message: "Missing ID or Server" });
  }

  try {
    // Simulate calling a real MLBB API (you can replace with real DuniaGames call)
    const result = {
      name: "Test Player",
      server: "SEA Server",
      country: "Myanmar"
    };

    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ message: "Internal Server Error" });
  }
}
